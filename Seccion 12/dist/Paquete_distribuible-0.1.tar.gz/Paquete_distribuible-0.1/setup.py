from setuptools import setup

setup(
    name="Paquete_distribuible",
    version="0.1",
    description="Mi primer paquete",
    author="Juan Pablo Cesarini",
    packages=["Paquete_distribuible","Paquete_distribuible.operaciones1"]
)